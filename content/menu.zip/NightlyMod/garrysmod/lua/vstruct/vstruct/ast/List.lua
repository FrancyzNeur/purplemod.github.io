local Node = require "vstruct.ast.Node"

return Node:copy()
